const express = require('express');
const passport = require('passport');
const { jwtAuth, secretOrKey } = require('./passport');
const jwt = require('jsonwebtoken');

passport.use(jwtAuth);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(passport.initialize());

function generateToken(user) {
    const token = jwt.sign({ user }, secretOrKey, {
        expiresIn: '1h',
    });
    return token;
}

app.post('/login', (req, res) => {
    const { username, password } = req.body;

   
    if (username === 'admin' && password === 'password') {
        const token = generateToken(username);
        res.json({ token });
    } else {
        res.status(401).json({ error: 'Invalid username or password' });
    }
});

app.post('/add', passport.authenticate('jwt', { session: false }), (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 + num2;
    res.json({ result });
});

app.post('/subtract', passport.authenticate('jwt', { session: false }), (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 - num2;
    res.json({ result });
});

app.post('/multiply', passport.authenticate('jwt', { session: false }), (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    const result = num1 * num2;
    res.json({ result });
});

app.post('/divide', passport.authenticate('jwt', { session: false }), (req, res) => {
    const { num1, num2 } = req.body;

    if (!isValidNumbers(num1, num2)) {
        return res.status(400).json({ error: 'Invalid input parameters' });
    }

    if (num2 === 0) {
        return res.status(400).json({ error: 'Division by zero is not allowed' });
    }

    const result = num1 / num2;
    res.json({ result });
});

app.listen(port, () => {
    console.log(`Calculator microservice with auth listening at http://localhost:${port}`);
});
