const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;

const secretOrKey = 'your_jwt_secret';

const jwtOptions = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey,
};

const jwtAuth = new JwtStrategy(jwtOptions, (payload, done) => {
    
    const user = payload.user;
    if (user) {
        return done(null, user);
    } else {
        return done(null, false);
    }
});

exports.jwtAuth = jwtAuth;
exports.secretOrKey = secretOrKey;
